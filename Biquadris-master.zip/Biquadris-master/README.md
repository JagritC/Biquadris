# CS246 A5: Biquadris

![Biquadris Text-View](https://github.com/kimiashaban/Biquadris/blob/master/Screen%20Shot%202020-05-15%20at%205.11.54%20PM.png)



![Biquadris Graphical Display-View](https://github.com/kimiashaban/Biquadris/blob/master/Screen%20Shot%202020-05-15%20at%205.12.00%20PM.png)
